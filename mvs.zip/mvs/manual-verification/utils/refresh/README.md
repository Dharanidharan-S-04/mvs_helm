# Restart MOSIP modules

Shell script to restart all MOSIP core modules in the right sequence. This is pod level restart on Kubernetes.
