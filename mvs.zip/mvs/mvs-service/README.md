# Admin Service

Helm chart for installing MOSIP Admin module

## TL;DR

```console
$ helm repo add mosip https://mosip.github.io
$ helm install my-release mosip/admin
```
